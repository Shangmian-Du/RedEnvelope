/********************************************************************************
** Form generated from reading UI file 'Window1.ui'
**
** Created by: Qt User Interface Compiler version 6.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WINDOW1_H
#define UI_WINDOW1_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Window1
{
public:
    QLabel *label;
    QPushButton *pushButton;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_2;
    QLineEdit *lineEdit_3;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;

    void setupUi(QWidget *Window1)
    {
        if (Window1->objectName().isEmpty())
            Window1->setObjectName("Window1");
        Window1->resize(251, 350);
        label = new QLabel(Window1);
        label->setObjectName("label");
        label->setGeometry(QRect(90, 20, 91, 31));
        QFont font;
        font.setFamilies({QString::fromUtf8("\351\273\221\344\275\223")});
        font.setPointSize(20);
        font.setBold(false);
        label->setFont(font);
        pushButton = new QPushButton(Window1);
        pushButton->setObjectName("pushButton");
        pushButton->setGeometry(QRect(60, 260, 141, 41));
        QFont font1;
        font1.setPointSize(18);
        pushButton->setFont(font1);
        lineEdit = new QLineEdit(Window1);
        lineEdit->setObjectName("lineEdit");
        lineEdit->setGeometry(QRect(80, 70, 131, 41));
        lineEdit_2 = new QLineEdit(Window1);
        lineEdit_2->setObjectName("lineEdit_2");
        lineEdit_2->setGeometry(QRect(80, 130, 131, 41));
        lineEdit_3 = new QLineEdit(Window1);
        lineEdit_3->setObjectName("lineEdit_3");
        lineEdit_3->setGeometry(QRect(80, 190, 131, 41));
        label_2 = new QLabel(Window1);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(30, 70, 41, 31));
        QFont font2;
        font2.setPointSize(14);
        label_2->setFont(font2);
        label_3 = new QLabel(Window1);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(30, 130, 41, 31));
        label_3->setFont(font2);
        label_4 = new QLabel(Window1);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(30, 190, 41, 31));
        label_4->setFont(font2);

        retranslateUi(Window1);

        QMetaObject::connectSlotsByName(Window1);
    } // setupUi

    void retranslateUi(QWidget *Window1)
    {
        Window1->setWindowTitle(QCoreApplication::translate("Window1", "Widget", nullptr));
        label->setText(QCoreApplication::translate("Window1", "\345\217\221\347\272\242\345\214\205", nullptr));
        pushButton->setText(QCoreApplication::translate("Window1", "\345\241\236\351\222\261\350\277\233\347\272\242\345\214\205", nullptr));
        label_2->setText(QCoreApplication::translate("Window1", "\351\207\221\351\242\235", nullptr));
        label_3->setText(QCoreApplication::translate("Window1", "\344\273\275\346\225\260", nullptr));
        label_4->setText(QCoreApplication::translate("Window1", "\345\244\207\346\263\250", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Window1: public Ui_Window1 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WINDOW1_H
