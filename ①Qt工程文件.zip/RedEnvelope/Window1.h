#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>

QT_BEGIN_NAMESPACE
namespace Ui {
class Window1;
}
QT_END_NAMESPACE

class Window1 : public QWidget
{
    Q_OBJECT

public:
    Window1(QWidget *parent = nullptr);
    ~Window1();

private slots:
    void on_pushButton_clicked();

    void on_lineEdit_textEdited(const QString &arg1);

    void on_lineEdit_2_textEdited(const QString &arg1);

    void on_lineEdit_3_textEdited(const QString &arg1);

private:
    Ui::Window1 *ui;
    QWidget *Widget;
};
#endif // WIDGET_H
