#ifndef WINDOW2_H
#define WINDOW2_H

#include <QDialog>

QT_BEGIN_NAMESPACE
namespace Ui {
class Window2;
}
QT_END_NAMESPACE

class Window2 : public QDialog
{
    Q_OBJECT

public:
    explicit Window2(QWidget *parent = nullptr);
    ~Window2();
    // 添加一个方法，用于接收并显示 result 数据
    void displayResult(const QVector<double> &result);

    void updateTextEdit(const QString &text); // 更新文本

private slots:

    void on_textEdit_windowIconTextChanged(const QString &iconText);

    void on_textEdit_2_windowIconTextChanged(const QString &iconText);

private:
    Ui::Window2 *ui;
};
#endif // WIDGET_H
