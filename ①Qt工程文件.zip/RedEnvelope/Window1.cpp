#include "Window1.h"
#include "ui_Window1.h"
#include <QWidget>
#include <QPushButton>
#include <QLineEdit>
#include <QLabel>
#include <QVBoxLayout>
#include <QMessageBox>
#include <QTextStream>
#include <QRandomGenerator>
#include <QMessageBox>
#include <QFont>
#include <QCoreApplication>
#include <QVector>
#include <algorithm>
#include "Window2.h"

Window1::Window1(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Window1)
    , Widget(nullptr)
{
    ui->setupUi(this);
    this->setWindowTitle("抢红包界面");

    QFont font = ui->lineEdit->font();
    font.setPointSize(14);
    ui->lineEdit->setFont(font);

    font = ui->lineEdit_2->font();
    font.setPointSize(14);
    ui->lineEdit_2->setFont(font);

    font = ui->lineEdit_3->font();
    font.setPointSize(14);
    ui->lineEdit_3->setFont(font);
}

Window1::~Window1()
{
    delete ui;
}

//用于按照人数对红包进行随机拆分并分组的序列
QVector<double> splitAndRandomize(double total, int people) {

    QVector<double> boundaries;
    boundaries.append(0);
    boundaries.append(total);

    // 使用 QRandomGenerator 生成随机边界
    for (int i = 0; i < people - 1; ++i) {
        boundaries.append(QRandomGenerator::global()->bounded(total));
    }

    // 对边界排序
    std::sort(boundaries.begin(), boundaries.end());

    // 计算分段长度
    QVector<double> segments;
    for (int i = 1; i < boundaries.size(); ++i) {
        segments.append(boundaries[i] - boundaries[i - 1]);
    }

    // 随机排列
    std::shuffle(segments.begin(), segments.end(), std::default_random_engine(static_cast<unsigned int>(QRandomGenerator::global()->generate())));

    return segments;
}

void Window1::on_pushButton_clicked()
{
    bool ok1 , ok2;
    double totalAmount = ui->lineEdit->text().toDouble(&ok1);
    int numPeople = ui->lineEdit_2->text().toInt(&ok2);
    QString text = ui->lineEdit_3->text();

    if (!ok1 || totalAmount <= 0) {
        QMessageBox::warning(this, "    错误", "请输入有效的金额！");
        return;
    }
    if (!ok2 || numPeople <= 0) {
        QMessageBox::warning(this, "错误", "请输入有效的人数！");
        return;
    }
    double minAmount = 0.01;
    if (totalAmount < minAmount * numPeople) {
        QMessageBox::warning(this, "错误", "金额不足以分配给所有人！");
        return;
    }

    //结合函数计算每个人的红包信息存放到result向量中
    QVector<double> result = splitAndRandomize(totalAmount, numPeople);
    Window2 *window2 = new Window2();
    window2->displayResult(result);
    window2->updateTextEdit(text);
    window2->show();
    this->close();
}


void Window1::on_lineEdit_textEdited(const QString &arg1)
{
    bool ok;
    double money = arg1.toDouble(&ok);
    if (money <= 0) {
        ui->lineEdit->setText("金额输入错误");
        QFont font = ui->lineEdit->font();
        font.setPointSize(14);
        ui->lineEdit->setFont(font);
        return;
    }
}


void Window1::on_lineEdit_2_textEdited(const QString &arg1)
{
    bool ok;
    int copies = arg1.toInt(&ok);
    if (copies <= 0) {
        ui->lineEdit_2->setText("人数输入错误");
        QFont font = ui->lineEdit_2->font();
        font.setPointSize(14); // 设置字体大小为 14
        ui->lineEdit_2->setFont(font);
        return;
    }
}


void Window1::on_lineEdit_3_textEdited(const QString &arg1)
{

}

