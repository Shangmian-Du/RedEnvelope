#include "Window1.h"
#include "Window2.h"
#include <QApplication>
#include <QWidget>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Window1 w;
    w.show();
    return a.exec();
}
