/********************************************************************************
** Form generated from reading UI file 'Window2.ui'
**
** Created by: Qt User Interface Compiler version 6.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WINDOW2_H
#define UI_WINDOW2_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_Window2
{
public:
    QLabel *label;
    QTextEdit *textEdit;
    QTextEdit *textEdit_2;

    void setupUi(QDialog *Window2)
    {
        if (Window2->objectName().isEmpty())
            Window2->setObjectName("Window2");
        Window2->resize(251, 350);
        label = new QLabel(Window2);
        label->setObjectName("label");
        label->setGeometry(QRect(70, 10, 111, 21));
        QFont font;
        font.setPointSize(16);
        label->setFont(font);
        textEdit = new QTextEdit(Window2);
        textEdit->setObjectName("textEdit");
        textEdit->setGeometry(QRect(20, 90, 211, 231));
        textEdit_2 = new QTextEdit(Window2);
        textEdit_2->setObjectName("textEdit_2");
        textEdit_2->setGeometry(QRect(20, 40, 211, 31));

        retranslateUi(Window2);

        QMetaObject::connectSlotsByName(Window2);
    } // setupUi

    void retranslateUi(QDialog *Window2)
    {
        Window2->setWindowTitle(QCoreApplication::translate("Window2", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("Window2", "\346\212\242\347\272\242\345\214\205\347\273\223\346\236\234", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Window2: public Ui_Window2 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WINDOW2_H
