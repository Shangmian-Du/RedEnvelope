#include "Window2.h"
#include "ui_Window2.h"
#include <QWidget>
#include <QPushButton>
#include <QLineEdit>
#include <QLabel>
#include <QVBoxLayout>
#include <QMessageBox>
#include <QTextStream>
#include <QTextEdit>
#include <QDebug>

Window2::Window2(QWidget *parent) // 使用 QWidget 作为父类类型
    : QDialog(parent)
    , ui(new Ui::Window2)
{
    ui->setupUi(this);
    ui->setupUi(this);
    this->setWindowTitle("抢红包结果");
}

Window2::~Window2()
{
    delete ui;
}

void Window2::displayResult(const QVector<double> &result)
{
    QString resultText;

    // 构建按行输出的文本内容
    for (int i = 0; i < result.size(); ++i) {
        resultText += QString("Person %1: %2\n").arg(i + 1).arg(result[i], 0, 'f', 2);
    }

    // 调用 on_textEdit_windowIconTextChanged，更新界面显示
    on_textEdit_windowIconTextChanged(resultText);
}

void Window2::on_textEdit_windowIconTextChanged(const QString &iconText)
{
    // 确保 widget_2 是 QTextEdit
    auto textEdit = qobject_cast<QTextEdit *>(ui->textEdit);
    if (textEdit) {
        textEdit->setText(iconText); // 更新内容到 widget_2
    } else {
        qWarning() << "widget_2 is not a QTextEdit!";
    }
}

void Window2::updateTextEdit(const QString &text)
{
    // 调用 on_textEdit_2_windowIconTextChanged 来显示传递的 text
    on_textEdit_2_windowIconTextChanged(text);
}

void Window2::on_textEdit_2_windowIconTextChanged(const QString &iconText)
{
    // 确保 widget_2 是 QTextEdit 类型
    auto textEdit = qobject_cast<QTextEdit *>(ui->textEdit_2);
    if (textEdit) {
        textEdit->setText(iconText); // 更新内容到 textEdit_2
    } else {
        qWarning() << "textEdit_2 is not a QTextEdit!";
    }
}
